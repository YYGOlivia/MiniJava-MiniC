/**
 * 
 */
package fr.n7.stl.minic.ast.expression.accessible;

import fr.n7.stl.minic.ast.expression.Expression;

/**
 * Expression whose value can be read.
 * 
 * @author Marc Pantel
 *
 */
public interface AccessibleExpression extends Expression {

}
