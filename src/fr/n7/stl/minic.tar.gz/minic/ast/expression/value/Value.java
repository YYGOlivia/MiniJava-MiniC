/**
 * 
 */
package fr.n7.stl.minic.ast.expression.value;

import fr.n7.stl.minic.ast.expression.accessible.AccessibleExpression;

/**
 * @author Marc Pantel
 *
 */
public interface Value extends AccessibleExpression {

}
